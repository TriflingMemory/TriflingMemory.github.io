This program requires python3 or later.
See: http://www.python.org/

Installing into the sytem:

    python setup.py install

Invoking the program:

    mergeImage composite.png base.png A.png B.png

First argument is output path.
Second argument is base image.
The next images are the images who deviated from the base image.
The last image will prevail in case of a conflict.

