This program requires python3 or later.
See: http://www.python.org/

Installing into the sytem:

    python setup.py install

Invoking the program:

    asvgasm 0000.png 0001.png ect.png > output.svg

The program arguments are the different png frames. It will output the svg to stdout.

Not implemented due to laziness:
All images should be same size.
All images should be png's.

